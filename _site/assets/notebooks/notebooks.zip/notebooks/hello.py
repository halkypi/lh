print("Hello from 'hello.py")
